import React from 'react'

const Burbujas = () => {
    return (
     
        <main className="bg_animate">
        <div className="header_nav">

        <h1 id="Dedicamos"><strong>Somos REMI Tu plataforma confiable para<br/> conseguir servicios<br/> de barberia en tu Ciudad</strong></h1>

        <h1 id="Establecimientos"><strong>¿Necesitas un Corte?<br/> Solicita a domicilio<br/> o aparta cita en tu barberia<br/> Favorita</strong></h1>
        
        <img className="Corte1" src="https://res.cloudinary.com/dtkirmtfq/image/upload/v1632815709/Remi/Imagen4_zxathr.png" alt="" />
        <img className="Corte2" src="https://res.cloudinary.com/dtkirmtfq/image/upload/v1632815918/Remi/Imagen5_q9wpep.png" alt="" />
        <h2 className="VamosRegistrate">¿Ya estas usando REMI? ¡ Registrate !</h2>
        </div>
 
        <section className="banner contenedor">
            <secrion className="banner_title">
                <h2> <br/>  </h2>
               
            </secrion>
            <div className="banner_img">
                <img src="laptop-support.png" alt=""/>
            </div>
        </section>

        <div className="burbujas">
            <div className="burbuja"></div>
            <div className="burbuja"></div>
            <div className="burbuja"></div>
            <div className="burbuja"></div>
            <div className="burbuja"></div>
            <div className="burbuja"></div>
            <div className="burbuja"></div>
            <div className="burbuja"></div>
            <div className="burbuja"></div>
            <div className="burbuja"></div>
        </div>
    </main>
    )
}

export default Burbujas
