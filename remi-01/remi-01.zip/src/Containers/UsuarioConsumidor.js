import React from 'react'
import NavBar from '../Components/NavBar'
import Profesionales from '../Components/Profesionales'

const UsuarioConsumidor = () => {
    return (
        <div>
            <NavBar />
            <Profesionales />
        </div>
    )
}

export default UsuarioConsumidor
   